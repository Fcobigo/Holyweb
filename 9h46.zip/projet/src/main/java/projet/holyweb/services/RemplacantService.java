package projet.holyweb.services;

import java.io.IOException;
import java.util.List;

import projet.holyweb.entities.Remplacant;
import projet.holyweb.managers.RemplacantDAO;

public class RemplacantService {

private RemplacantDAO RemplacantDAO = new RemplacantDAO();
	
	private static class RemplacantServiceHolder{
		private static RemplacantService instance = new RemplacantService();
	}
	
	public static RemplacantService getInstance(){
		return RemplacantServiceHolder.instance;
	}
	private RemplacantService(){}
	
	public List<Remplacant> ListRemplacant(){
		return RemplacantDAO.listRemplacant();
	}
	
	public Remplacant getRemplacant(Integer idRemplacant){
		return RemplacantDAO.getRemplacant(idRemplacant);
	}
	
	public void updateConge(Integer idRemplacant, Integer idEmployeRemplacant, Integer idEmployeRemplace, Integer idDispo) throws IOException{
		RemplacantDAO.updateRemplacant(idRemplacant, idEmployeRemplacant, idEmployeRemplace, idDispo);
	}
	
	public void addRemplacant(Remplacant nouveauRemplacant){
		RemplacantDAO.addRemplacant(nouveauRemplacant);
	}
	
	public void deleteRemplacant(Integer idRemplacant){
		RemplacantDAO.deleteRemplacant(idRemplacant);
	}
}
