package projet.holyweb.managers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import projet.holyweb.dao.impl.DataSourceProvider;
import projet.holyweb.entities.Remplacant;

public class RemplacantDAO {

public List<Remplacant> listRemplacant(){
		
		List<Remplacant> Remplacant = new ArrayList<Remplacant>();
		
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery("SELECT * FROM remplacant")){
			
					while (resultSet.next())
						Remplacant.add(new Remplacant(
								resultSet.getInt("idRemplacant"),
								resultSet.getInt("idEmployeRemplacant"),
								resultSet.getInt("idEmployeRemplace"),
								resultSet.getInt("idDispo")
								));
					}
	
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return Remplacant;
	}

	public Remplacant getRemplacant(Integer idRemplacant){
		
		Remplacant Remplacant = null;
		
		try{
			Connection connection = DataSourceProvider.getDataSource().getConnection();
			PreparedStatement stmt = connection.prepareStatement("SELECT * FROM remplacant WHERE idRemplacant=?");
			stmt.setInt(1, idRemplacant);
			ResultSet resultSet = stmt.executeQuery();
			if(resultSet.next()){
				Remplacant = new Remplacant(
						resultSet.getInt("idRemplacant"),
						resultSet.getInt("idEmployeRemplacant"),
						resultSet.getInt("idEmployeRemplace"),
						resultSet.getInt("idDispo")
						);
			}
			stmt.close();
			connection.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
		return Remplacant;
	}
	
	//Mise à jour remplacant
	public void updateRemplacant(Integer idRemplacant, Integer idEmployeRemplacant, Integer idEmployeRemplace,
			Integer idDispo){
		
		try (Connection connection =DataSourceProvider.getDataSource().getConnection();
				PreparedStatement statement = connection.prepareStatement("UPDATE remplacant SET idRemplacant='"+idRemplacant+"',idEmployeRemplacant='"+idEmployeRemplacant+"', idEmployeRemplace='"+idEmployeRemplace+"', idDispo='"+idDispo+"'")){	
				statement.executeUpdate();
			} catch (SQLException e){
				e.printStackTrace();
			}
		
	}
	
	
	//Ajout remplacant
	public void addRemplacant(Remplacant Remplacants){
		try {
			Connection connection = DataSourceProvider.getDataSource().getConnection();
			PreparedStatement stmt = connection.prepareStatement("INSERT INTO remplacant(idRemplacant, idEmployeRemplacant, idEmployeRemplace, idDispo) VALUES (?,?,?,?)");
		
			
			stmt.setInt(1, Remplacants.getIdRemplacant());
			stmt.setInt(2, Remplacants.getIdEmployeRemplacant());
			stmt.setInt(3, Remplacants.getIdEmployeRemplace());
			stmt.setInt(7, Remplacants.getIdDispo());
			
			stmt.executeUpdate();
			stmt.close();
			
			connection.close();
		} catch (SQLException e){
			e.printStackTrace();
		}
		
	}
	
	//Supprimer remplacant
	public void deleteRemplacant(Integer idRemplacant){
		
		try {
            Connection connection = DataSourceProvider.getDataSource().getConnection();
            PreparedStatement stmt = connection.prepareStatement("DELETE FROM remplacant WHERE remplacant=?");
            stmt.setInt(1, idRemplacant);
            stmt.executeUpdate();
            stmt.close();
            
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
		
	}
}
