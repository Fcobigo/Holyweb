package projet.holyweb.entities;

public class Remplacant {
	
	//Définition de l'objet
	private Integer idRemplacant;
	private Integer idEmployeRemplacant;
	private Integer idEmployeRemplace;
	private Integer idDispo;

	public Remplacant(Integer idRemplacant, Integer idEmployeRemplacant,
			Integer idEmployeRemplace, Integer idDispo){
		
		super();
		this.idRemplacant = idRemplacant;
		this.idEmployeRemplacant = idEmployeRemplacant;
		this.idEmployeRemplace = idEmployeRemplace;
		this.idDispo = idDispo;
	}

	//Getters and Setters
	public Integer getIdRemplacant() {
		return idRemplacant;
	}

	public void setIdRemplacant(Integer idRemplacant) {
		this.idRemplacant = idRemplacant;
	}

	public Integer getIdEmployeRemplacant() {
		return idEmployeRemplacant;
	}

	public void setIdEmployeRemplacant(Integer idEmployeRemplacant) {
		this.idEmployeRemplacant = idEmployeRemplacant;
	}

	public Integer getIdEmployeRemplace() {
		return idEmployeRemplace;
	}

	public void setIdEmployeRemplace(Integer idEmployeRemplace) {
		this.idEmployeRemplace = idEmployeRemplace;
	}

	public Integer getIdDispo() {
		return idDispo;
	}

	public void setIdDispo(Integer idDispo) {
		this.idDispo = idDispo;
	}
	
	
}
