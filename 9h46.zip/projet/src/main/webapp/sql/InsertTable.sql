INSERT INTO `employe` (`idEmploye`, `mdpEmploye`, `dateNaissanceEmploye`, `nomEmploye`,
`prenomEmploye`, `telephoneEmploye`, `mailEmploye`, `interimaire`, `idCategorie`, `idConge`) 
VALUES
(NULL, 'ced282016fr', '12/12/1972', 'ALLAIN', 'Cedric', 0617502501, 'cedric56.allain@aliceadsl.fr', NULL,7, NULL),
(NULL, 'sam202016om', '15/01/1977', 'BARDOR', 'Samuel', 0650219020, 'sam.bard56@gmail.com', NULL, 7, NULL),
(NULL, 'kry182016fr', '16/03/1973', 'BRUNET', 'Christophe', 0685221656, 'krystale@orange.fr', NULL, 7, '1'),
(NULL, 'dan242016om', '03/10/1974', 'DANTEC', 'Mikael', 0660645852, 'dantec.mikael@cobigo.com', NULL, 11, '2'),
(NULL, 'cd252016om', '18/05/1973', 'DAMONNEVILLE', 'Cecile', 0682751112, 'c.damonneville@cobigo.com', NULL, 9, NULL),
(NULL, '1fac222016om', '19/06/1958', 'JOHNSTON', 'Ghislaine', 0672343953, 'facturation@cobigo.com', NULL, 2, NULL),
(NULL, 'pr202016om', '01/08/1971', 'ROLLAND', 'Patrick', 0614967160, 'p.rolland@cobigo.com', NULL, 8, NULL)
;

INSERT INTO `categorie` (`idCategorie`, `libelleCategorie`)
VALUES (1, 'Agent Administratif'),
(2, 'Agent Administratif'),
(3, 'Agent Entretien'),
(4, 'Assitant(e) d exploitation'),
(5, 'Chef de parc'),
(6, 'Compatibilite clients'),
(7, 'Conducteur(rice) routier(e)'),
(8, 'Directeur(rice) d exploitation'),
(9, 'Exploitant(e)'),
(10, 'Exploitant(e) MD'),
(11, 'Mecanicien(ne) poids lourd'),
(12, 'Responsable HSQE'),
(13, 'Autres')
;

INSERT INTO `conge` (`idConge`, `dateDebutConge`, `dateFinConge`, `matin`, `apresMidi`, `numeroSemaineConge`, 
`dateDemandeConge`, `etatDemande`, `dateValidation`, `idTypeConge`) VALUES 
(1, '12/10/2017', '23/10/2017', NULL, NULL, NULL, '03/04/2017', 'EnCours', NULL, 4),
(2, '05/06/2017', '10/06/2017', NULL, NULL, NULL, '23/02/2017', 'Valide', NULL,5)
;

INSERT INTO `typeConge` (`idTypeConge`, `libelleTypeConge`) VALUES
(1, 'RTT'),
(2, 'Maladie'),
(3, 'Maternite/Paternite'),
(4, 'Conges Payes'),
(5, 'Formation')
;

INSERT INTO `disponibilite` (`idDispo`, `dateDebutDispo`, `dateFinDispo`, `matin`, `apresMidi`, `affecte`, `idEmploye`) VALUES
(1,'12/03/2017', '23/03/2017', NULL, NULL, NULL, 2)
;

INSERT INTO `Remplacant` (`IdRemplacement`, `IdEmployeRemplacant`, `IdEmployeRemplace`, `IdDispo`) VALUES 
()
;